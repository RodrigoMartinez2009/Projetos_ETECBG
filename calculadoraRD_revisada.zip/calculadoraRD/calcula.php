<?php
$num1 = '';
$num2 = '';
$operacao = 'somar';
$resultado = null;
$erro = '';

if (isset($_POST['calcular'])) {
    $num1 = is_string($_POST['num1'] ?? null) ? trim($_POST['num1']) : '';
    $num2 = is_string($_POST['num2'] ?? null) ? trim($_POST['num2']) : '';
    $operacao = is_string($_POST['operacao'] ?? null) ? $_POST['operacao'] : '';

    if ($num1 === '' || $num2 === '' || !is_numeric($num1) || !is_numeric($num2)) {
        $erro = 'Informe dois números válidos.';
    } elseif (!in_array($operacao, ['somar', 'subtrair', 'multiplicar', 'dividir'], true)) {
        $erro = 'Selecione uma operação válida.';
    } else {
        $a = (float) $num1;
        $b = (float) $num2;

        if (!is_finite($a) || !is_finite($b)) {
            $erro = 'Informe dois números válidos.';
        } elseif ($operacao === 'dividir' && $b == 0) {
            $erro = 'Não é possível dividir por zero.';
        } else {
            switch ($operacao) {
                case 'somar':
                    $resultado = $a + $b;
                    break;
                case 'subtrair':
                    $resultado = $a - $b;
                    break;
                case 'multiplicar':
                    $resultado = $a * $b;
                    break;
                case 'dividir':
                    $resultado = $a / $b;
                    break;
            }

            if (!is_finite($resultado)) {
                $resultado = null;
                $erro = 'O resultado está fora do limite permitido.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Calculadora PHP</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            margin: 0;
            padding: 24px;
            display: grid;
            place-items: center;
            background: #fff;
            color: #000;
            font-family: Arial, sans-serif;
        }

        .calculadora {
            width: 100%;
            max-width: 360px;
            padding: 28px;
            border: 1px solid #000;
        }

        h1 {
            margin: 0 0 24px;
            font-size: 24px;
            font-weight: 600;
        }

        label {
            display: block;
            margin: 0 0 7px;
            font-size: 14px;
        }

        input, select, button {
            width: 100%;
            padding: 12px;
            font: inherit;
            border: 1px solid #000;
            border-radius: 0;
        }

        input, select {
            margin: 0 0 18px;
            background: #fff;
            color: #000;
        }

        button {
            background: #000;
            color: #fff;
            cursor: pointer;
        }

        button:hover {
            background: #fff;
            color: #000;
        }

        input:focus-visible, select:focus-visible, button:focus-visible {
            outline: 2px solid #000;
            outline-offset: 2px;
        }

        .mensagem {
            margin: 20px 0 0;
            padding-top: 16px;
            border-top: 1px solid #000;
            overflow-wrap: anywhere;
        }
    </style>
</head>
<body>
    <main class="calculadora">
        <h1>Calculadora</h1>

        <form method="post">
            <label for="num1">Primeiro número</label>
            <input id="num1" type="number" step="any" name="num1" value="<?= htmlspecialchars($num1, ENT_QUOTES, 'UTF-8') ?>" required>

            <label for="operacao">Operação</label>
            <select id="operacao" name="operacao">
                <option value="somar" <?= $operacao === 'somar' ? 'selected' : '' ?>>Adição (+)</option>
                <option value="subtrair" <?= $operacao === 'subtrair' ? 'selected' : '' ?>>Subtração (-)</option>
                <option value="multiplicar" <?= $operacao === 'multiplicar' ? 'selected' : '' ?>>Multiplicação (×)</option>
                <option value="dividir" <?= $operacao === 'dividir' ? 'selected' : '' ?>>Divisão (÷)</option>
            </select>

            <label for="num2">Segundo número</label>
            <input id="num2" type="number" step="any" name="num2" value="<?= htmlspecialchars($num2, ENT_QUOTES, 'UTF-8') ?>" required>

            <button type="submit" name="calcular">Calcular</button>
        </form>

        <?php if ($erro !== ''): ?>
            <p class="mensagem" role="alert"><?= htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') ?></p>
        <?php elseif ($resultado !== null): ?>
            <p class="mensagem" role="status">Resultado: <strong><?= htmlspecialchars((string) $resultado, ENT_QUOTES, 'UTF-8') ?></strong></p>
        <?php endif; ?>
    </main>
</body>
</html>
